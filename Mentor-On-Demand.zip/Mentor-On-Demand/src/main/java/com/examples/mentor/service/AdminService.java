package com.examples.mentor.service;

public interface AdminService {

}
