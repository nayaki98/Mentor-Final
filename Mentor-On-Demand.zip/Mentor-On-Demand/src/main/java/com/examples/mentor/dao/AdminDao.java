package com.examples.mentor.dao;



public interface AdminDao {

}
