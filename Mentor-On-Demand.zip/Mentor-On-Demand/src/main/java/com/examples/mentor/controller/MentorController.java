package com.examples.mentor.controller;

public interface MentorController {

}
