package com.examples.mentor.dao;

public class AdminDaoImpl {

}
