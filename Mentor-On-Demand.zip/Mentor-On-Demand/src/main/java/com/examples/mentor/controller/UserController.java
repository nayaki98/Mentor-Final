package com.examples.mentor.controller;

public interface UserController {

}
