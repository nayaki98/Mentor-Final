package com.examples.mentor.controller;

public interface SkillController {

}
