package com.examples.mentor.controller;

public interface LoginController {

}
